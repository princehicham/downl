/**
 * Plugin Template admin js.
 *
 *  @package WordPress Plugin Template/JS
 */

jQuery( document ).ready(
	function ( e ) {

	}
);
